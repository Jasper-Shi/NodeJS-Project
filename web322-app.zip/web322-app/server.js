
/*********************************************************************************
* WEB322 – Assignment 07
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this
* assignment has been copied manually or electronically from any other source (including web sites) or
* distributed to other students.
*
* Name: ____Ziyi Shi__________________ Student ID: _124812157_____________ Date: ___2018-01-05_____________
*
* Online (Heroku) Link: __________https://lit-lowlands-93262.herokuapp.com/login______________________________________________
*
********************************************************************************/

var express = require("express");
var app = express();
var path = require("path");
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
const clientSessions = require('client-sessions')
var dataServiceComments = require("./data-service-comments.js");
var dataServiceAuth = require("./data-service-auth.js");
var HTTP_PORT = process.env.PORT || 8080;


var data = require("./data-service.js"); // new

app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: true }));

app.engine(".hbs", exphbs({
    extname: ".hbs",
    defaultLayout: 'layout',
    helpers: {
    equal: function (lvalue, rvalue, options) {
    if (arguments.length < 3)
    throw new Error("Handlebars Helper equal needs 2 parameters");
    if (lvalue != rvalue) {
    return options.inverse(this);
    } else {
    return options.fn(this);
    }
    },
    inc: function(value, options)
    {
        return parseInt(value) + 1;
    }
    }
   }));
   app.set("view engine", ".hbs");

app.use(clientSessions({
    cookieName: "session",
    secret: "web322Assignment7",
    duration: 2 * 60 * 1000,
    activeDuration: 1000 * 60
}));

function ensureLogin(req, res, next) {
    if(!req.session.user)//res.local.session != req.session)
        res.redirect("/login");
    else{
        //res.redirect("/employees");
        next();
    }
}

app.use(function(req, res, next) {
    res.locals.session = req.session;
    next();
});

app.get("/", function(req,res){
    //res.send(employees,departments);
    //res.sendFile(path.join(__dirname + "/views/home.html"));
    res.render("home", {user: req.session.user});
});

data.initialize().then(function(){ // new
    dataServiceComments.initialize();
}).then(() => {
    dataServiceAuth.initialieze();
}).then(() => {
    app.listen(HTTP_PORT, function(){
        console.log("Express http server listening on port: " + HTTP_PORT);
    });
}).catch(function(err){
    console.log(err);
});


app.get("/about", function(req,res){
    //res.sendFile(path.join(__dirname + "/views/about.html"));
    dataServiceComments.getAllComments().then((data) => {
        res.render("about", {data: data, user: req.session.user});
    }).catch(() => {
        res.render("about");
    })
});
/*
app.get("/employee/:empNum", (req,res) =>{
    //res.send("Getting employees for empNum: " + req.params.empNum);
    data.getEmployeeByNum(req.params.empNum).then(function(data){
        //res.send(data)
        res.render("employee",{data: data});
    }).catch(function(err){
        //res.send(err);
        res.status(404).send("Employee Not Found");
    })
});
*/ // NEW app.get("/employee/:empNum")
app.get("/employee/:empNum", ensureLogin, (req, res) => {
    // initialize an empty object to store the values
    let viewData = {};
    data.getEmployeeByNum(req.params.empNum)
    .then((data) => {
        console.log("DATAAAAA: " + data);
        viewData.data = data; //store employee data in the "viewData" object as "data"
    }).catch(()=>{
        viewData.data = null; // set employee to null if there was an error
    }).then(data.getDepartments).then((data) => {
        viewData.departments = data; // store department data in the "viewData" object as "departments"
   
    // loop through viewData.departments and once we have found the departmentId that matches
    // the employee's "department" value, add a "selected" property to the matching
    // viewData.departments object
    for (let i = 0; i < viewData.departments.length; i++) {
    if (viewData.departments[i].departmentId == viewData.data.department) {
    viewData.departments[i].selected = true;
    }
    }
    }).catch(()=>{
    viewData.departments=[]; // set departments to empty if there was an error
    }).then(()=>{
    if(viewData.data == null){ // if no employee - return an error
    res.status(404).send("Employee Not Found");
    }else{
    res.render("employee", { viewData: viewData, user: req.session.user }); // render the "employee" view
    }
    });
   });
   
app.get("/department/:departmentId", ensureLogin, (req,res) => {
    data.getDepartmentById(req.params.departmentId).then((data) => {
        res.render("department", {data: data, user: req.session.user});
    }).catch((err) => {
        res.status(404).send("Department Not Found");
    })
});

/*
app.get("/e", (req, res) => {
    data.getAllEmployees().then(function(data){ // new
        res.json(data);
    }).catch(function(err){
        res.json(err);
    })
})
*/
app.get("/employees", ensureLogin, (req,res)=>{
    if(req.query.status){
        //res.send("Trying to find: " + req.query.status);
        data.getEmployeesByStatus(req.query.status).then(function(data){
            //res.json(data);
            //console.log(data);
            res.render("employeeList",{data:data, title:"Employees", user: req.session.user});
        }).catch(function(err){
            console.log(err);
        })
    }else if (req.query.department){
        //res.send("Trying to find: " + req.query.department);
        data.getEmployeesByDepartment(req.query.department).then(function(data){
            //res.json(data);
            res.render("employeeList", {data:data, title:"Employees", user: req.session.user});
        }).catch(function(err){
            res.json(err);
        })
    }else if (req.query.manager){
        //res.send("Trying to find: " + req.query.manager);
        data.getEmployeesByManager(req.query.manager).then(function(data){
            //res.json(data);
            res.render("employeeList", {data:data, title:"Employees", user: req.session.user});
        }).catch(function(err){
            res.json(err);
        })
    }else{
        data.getAllEmployees().then(function(data){
            //res.json(data);
            res.render("employeeList", { data: data, title: "Employees", user: req.session.user});
        }).catch(function(err){
            //res.json(err);
            res.render("employeeList", { data: {}, title: "Employees"});
        })
    }
});

app.get("/managers", ensureLogin, (req, res) => {
    //res.send("Tring to find manager: " );
    data.getManagers().then(function(data){
        //res.json(data);
        res.render("employeeList", {data: data, title: "Employees (Managers)", user: req.session.user});
    }).catch(function(err){
        //res.json(err);
        res.render("employeeList", {data: {}, title: "Employees (Managers)", user: req.session.user});
    })
  });

app.get("/departments", ensureLogin, (req, res) => {
    //res.send("Tring to find department: " );
    data.getDepartments().then(function(data){
        //res.json(data);
        res.render("departmentList",{
            data: data,
            title: "Departments",
            user: req.session.user
        })
    }).catch(function(err){
        //res.json(err);
        res.render("departmentList",{
            data: {},
            title: "Departments",
            user: req.session.user
        })
    })
  });

  app.get("/employees/add", ensureLogin, (req,res) => {
    data.getDepartments().then((data) => {
        res.render("addEmployee", {departments:data});
    }).catch(() => {
        res.render("addEmployee", {departments: [], user: req.session.user})
    })
   });

   app.get("/departments/add", ensureLogin, (req,res) => {
       res.render("addDepartment", {title: "Department", user: req.session.user})
   });

   app.get("/employee/delete/:empNum", ensureLogin, (req,res) => {
       data.deleteEmployeeByNum(req.params.empNum).then(() => {
           res.redirect("/employees");
       }).catch(() => {
           res.status(500).send( "Unable to Remove Employee / Employee not found");
       })
   });

   app.get("/login", (req, res) => {
       res.render("login.hbs");
   });

   app.get("/register", (req, res) => {
       res.render("register.hbs");
   });

   app.get("/logout", (req, res) => {
       req.session.reset();
       res.redirect("/");
   });
  //POST 
   app.post("/employees/add", ensureLogin, (req, res) => {
    console.log(req.body);
    data.addEmployee(req.body).then(function(){
        console.log(req.body);
        res.redirect("/employees");
    })
   });

   app.post("/department/add", ensureLogin, (req, res) => {
       console.log("department adding info" + req.body);
       data.addDepartment(req.body).then(() => {
           res.redirect("/departments")
       })
   });

   app.post("/employee/update", ensureLogin, (req, res) => {
    console.log(req.body);
    data.updateEmployee(req.body).then(function(){
        res.redirect("/employees");
    })
   });

   app.post("/department/update", ensureLogin, (req, res) => {
       console.log(req.body);
       data.updateDepartment(req.body).then(() => {
           res.redirect("/departments");
       })
   });

   app.post("/about/addComment", (req, res) => {
       dataServiceComments.addComment(req.body).then(() =>{
           res.redirect("/about");
       }).catch((err) => {
           console.log(err);
           res.redirect("/about");
       })
   });

   app.post("/about/addReply", (req, res) => {
       dataServiceComments.addReply(req.body).then(() => {
           res.redirect("/about");
       }).catch((err) => {
           console.log(err);
           res.redirect("/about");
       })
   });

   app.post("/register", (req, res) => {
       dataServiceAuth.registerUser(req.body).then(() => {
           res.render("register.hbs", {successMessage: "User craeted"});
       }).catch((err) => {
           res.render("register.hbs", {errorMessage: err, user: req.body.user});
       });
   });

   app.post("/login", (req, res) => {
       dataServiceAuth.checkUser(req.body).then(() => {
           const username = req.body.user
           console.log("11111111 ");
           req.session.user = {
               username: username
           };
          
           res.redirect("/employees");
           console.log("2222");
       }).catch((err) => {
           //console.log("went here!!!");
           res.render('login.hbs', {errorMessage: err, user: req.body.user});
       });
   });

app.use((req, res) => {
    res.status(404).send('<img src="https://learn.getgrav.org/user/pages/11.troubleshooting/01.page-not-found/error-404.png" style="width:100%; height:100%"/>')
  });


