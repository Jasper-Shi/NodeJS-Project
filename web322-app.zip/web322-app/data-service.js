const Sequelize = require('sequelize');

var sequelize = new Sequelize('dbi3mba94d1p27', 'osjruqagsfxavu', '2376d61a0a309c1baa5d997e867fc043419a012e7471a1aecbf8e2171290dff5', {
    host: 'ec2-23-23-92-179.compute-1.amazonaws.com',
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
    ssl: true
    }
   });

   sequelize.authenticate().then(() => {
        console.log('Connection has been established successfully.');
    }).catch((err) => {
        console.log('Unable to connect to the database:', err);
    });

var Employee = sequelize.define('Employee', {
    employeeNum: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    email: Sequelize.STRING,
    SSN: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressState: Sequelize.STRING,
    addressPostal: Sequelize.STRING,
    maritalStatus: Sequelize.STRING,
    isManager: Sequelize.BOOLEAN,
    employeeManagerNum: Sequelize.INTEGER,
    status: Sequelize.STRING,
    department: Sequelize.INTEGER,
    hireDate: Sequelize.STRING,
},{
    createdAt: false, // disable createdAt
    updatedAt: false // disable updatedAt
});

var Department = sequelize.define('Department', {
    departmentId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    departmentName: Sequelize.STRING
},{
    createdAt: false, // disable createdAt
    updatedAt: false // disable updatedAt
});

module.exports.initialize = function(){
    return new Promise(function(resolve,reject){
        sequelize.sync().then((Employee) => {
            resolve();
        }).then((Department) => {
            resolve();
        }).catch((err) => {
            reject("unable to sync the database");
        });
    });
}

module.exports.getAllEmployees = function(){ // new
    return new Promise(function(resolve,reject){
        sequelize.sync().then(() => {
            Employee.findAll().then((data) => {
                console.log("1Successfully read all employees");
                resolve(data);
            }).catch((err) => {
                console.log("1no results returned");
                reject("no results returned");
            })
        })
    });
};

module.exports.getEmployeesByStatus = function(PtyStatus){
    return new Promise(function(resolve, reject){
        sequelize.sync().then(() => {
            Employee.findAll({
                where: {
                    status: PtyStatus
                }
            }).then((data) => {
                console.log("2successfully read data");
                resolve(data);
            }).catch((err) => {
                console.log("2no results returned");
                reject("no results returned");
            })
        })
    })
}

module.exports.getEmployeesByDepartment = function(departNum){
    return new Promise(function (resolve,reject){
        sequelize.sync().then(() => {
            Employee.findAll({
                where: {
                    department: departNum
                }
            }).then((data) => {
                console.log("3successfully read data");
                resolve(data);
            }).catch((err) => {
                console.log("3no results returned");
                reject("no results returned");
            })
        })
    });
}

module.exports.getEmployeesByManager = function(managerNum){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
            Employee.findAll({
                where: {
                    employeeManagerNum: managerNum
                }
            }).then((data) => {
                console.log("4succssfully read data");
                resolve(data);
            }).catch((err) => {
                console.log("4no results returned");
                reject("no results returned");
            })
        })
    })
}

module.exports.getEmployeeByNum = function(num){
     return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
            Employee.findAll({
                where: {
                    employeeNum: num
                }
            }).then((data) => {
                console.log("5successfully read data");
                resolve(data);
            }).catch((err) => {
                console.log("5no results returned");
                reject("no results returned");
            })
        })
     })
 }

 module.exports.getDepartmentById = function(id){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
        Department.findAll({
            where:{departmentId: id}
        }).then((data) => {
            console.log("department found");
            console.log(data);
            resolve(data);
        }).catch(() => {
            console.log("8no results returned");
            reject("no results returned");
        })
    })
    })
}

module.exports.getManagers = function(){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
            Employee.findAll({
                where: {
                    isManager: true
                }
            }).then((data) => {
                console.log("6successfully read the data");
                resolve(data);
            }).catch((err) => {
                console.log("6no results returned");
                reject("no results returned");
            })
        })
    })
}

module.exports.getDepartments = function(){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
        Department.findAll().then((data) => {
            console.log("7successfully read data");
            resolve(data);
        }).catch((err) => {
            console.log("7no results returned");
            reject("no results returned");
        })
    })
    })
}

module.exports.addEmployee = function(employeeData){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
            employeeData.isManager = (employeeData.isManager) ? true : false;
            for(let x in employeeData){
                if(employeeData[x] == ""){
                    employeeData[x]=null;
                }
            }

            Employee.create({
                employeeNum: employeeData.employeeNum,
                firstName: employeeData.firstName,
                lastName: employeeData.lastName,
                email: employeeData.email,
                SSN: employeeData.SSN,
                addressStreet: employeeData.addressStreet,
                addressCity: employeeData.addressCity,
                addressState: employeeData.addressState,
                addressPostal: employeeData.addressPostal,
                maritalStatus: employeeData.maritalStatus,
                isManager: employeeData.isManager,
                employeeManagerNum: employeeData.employeeManagerNum,
                status: employeeData.status,
                department: employeeData.department,
                hireDate: employeeData.hireDate
            }).then(() => {
                console.log("added");
                resolve();
            }).catch(() => {
                console.log("fail");
                reject("unable to create employee");
            })
        })
    })
}

module.exports.updateEmployee = function(employeeData){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
        employeeData.isManager = (employeeData.isManager) ? true : false;
        for(let x in employeeData){
            if(employeeData[x] == ""){
                employeeData[x]=null;
            }
        }
        Employee.update({
            employeeNum: employeeData.employeeNum,
            firstName: employeeData.firstName,
            lastName: employeeData.lastName,
            email: employeeData.email,
            SSN: employeeData.SSN,
            addressStreet: employeeData.addressStreet,
            addressCity: employeeData.addressCity,
            addressState: employeeData.addressState,
            addressPostal: employeeData.addressPostal,
            maritalStatus: employeeData.maritalStatus,
            isManager: employeeData.isManager,
            employeeManagerNum: employeeData.employeeManagerNum,
            status: employeeData.status,
            department: employeeData.department,
            hireDate: employeeData.hireDate
        },{
            where: {employeeNum: employeeData.employeeNum}
        }).then(() => {
            console.log("updated");
            resolve();
        }).catch(() => {
            console.log("unable to update");
            reject("unable to update");
        })
    })
    })
}

module.exports.addDepartment = function(departmentData){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
        for(let x in departmentData){
            if(departmentData[x] == ""){
                departmentData[x]=null;
            }
        }

        Department.create({
            departmentId: departmentData.departmentId,
            departmentName: departmentData.departmentName
        }).then(() => {
            console.log("department added");
            resolve();
        }).catch(() => {
            console.log("unable to create department");
            reject("unable to create department");
        })
    })
    })
}

module.exports.updateDepartment = function(departmentData){
    return new Promise((resolve, reject) => {
        sequelize.sync().then(() => {
        for(let x in departmentData){
            if(departmentData[x] == ""){
                console.log("4325324   " + departmentData[x]);
                departmentData[x]=null;
            }
        }

        Department.update({
            departmentName: departmentData.departmentName
        },{
            where: {
                departmentId: departmentData.departmentId
            }
        }).then(() => {
            console.log("department updated");
            resolve();
        }).catch(() => {
            console.log("update failed");
            reject("unable to update department")
        })
    })
    })
}

module.exports.deleteEmployeeByNum = function(empNum){
    return new Promise ((resolve, reject) => {
        sequelize.sync().then(() => {
        Employee.destroy({
            where: {employeeNum: empNum}
        }).then(() => {
            resolve("destroyed");
        }).catch(() => {
            reject("was rejected");
        })
    })
    })
}
