const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
let Schema = mongoose.Schema;

var userSchema = new Schema({
    "user": {
        type: String,
        unique: true
    },
    "password": String
});

let User;

module.exports.initialieze = function() {
    return new Promise (function(resolve, reject){
        let db = mongoose.createConnection("mongodb://user1:Neverregret@ds133627.mlab.com:33627/web322_a7");
        db.on('error', (err)=>{
            reject(err);
        });
        db.once('open', ()=>{
            User = db.model("users", userSchema);
            resolve();
        });
    })
};

module.exports.registerUser = function(userData) {
    return new Promise (function (resolve, reject) {
        if(userData.password != userData.password2){
            console.log("p1: " + userData.password);
            console.log("p2: " + userData.password2);
            reject("Passwords do not match");
        }
        else{
            console.log("userData: " + userData);
            let newUser = new User(userData);
            console.log("newUser: " + newUser);
            bcrypt.genSalt(10, (err, salt) => {
                if(err){
                    console.log("Error occured encrypting password");
                }else{
                    bcrypt.hash(userData.password, salt, (err, hash)=>{
                        if(err){
                            console.log("Error occured encrypting userData.password");
                        }else{
                            newUser.password = hash;
                            newUser.save((err) => {
                                if(err){
                                    console.log('There was an error saving newUser' + err);
                                    if(err.code == 11000){
                                        reject("User Name already taken");
                                    }
                                    else if(err.code != 11000){
                                        reject('There was an error creating the user: ' + err)
                                    }
                                }
                                else{
                                    
                                    console.log('newUser was saved to web322_a7');
                                    resolve();
                                }
                            });
                        }
                    });
                }
            });
        }
    });
};

module.exports.checkUser = function(userData){
    return new Promise (function (resolve, reject) {
        User.find({user: userData.user})
        .exec()
        .then((users) => {
            //console.log("user: " + user);
            if(users.length == 0){
                console.log("users.length" + users.length);
                reject("Unable to find the user: " + user);
            }/*
            else if(users[0].password != userData.password){
                console.log("p1: " + users[0].password);
                console.log("p2: " + userData.password);
                console.log("user: " + users); console.log("userData.password" + userData.password);
                reject("Incorrect Password for user: " + userData.user);
            }*/
            else /*if(users[0].password == userData.password)*/{
                hash = users[0].password;
                bcrypt.compare(userData.password, hash, (err, result) => {
                    if(err){throw {err}}
                    if(result == true){
                        console.log("Password matches");
                        resolve();
                    }else if(result == false){
                        console.log("Password does not match");
                        reject();
                    }
                });
            }
        }).catch(() => {
            //console.log("243244444444444432");
            reject("Unable to find user: " + userData.user);
        });
    });
};

